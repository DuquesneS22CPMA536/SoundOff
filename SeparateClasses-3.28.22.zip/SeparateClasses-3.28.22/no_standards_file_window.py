import tkinter as tk
from tkinter import ttk


class NoStandardsWindow(tk.Toplevel):
    """A SoundOff window.

    Will hold a primary window with functions to select a wav file, test the wav file's peak value against
    a standard's peak value, and test the wav file's LUF value against a standard's LUF value.

    """

    def __init__(self, parent):
        """Initializes the main window application

        Will hold buttons for the main functions and store platform information by accessing the standards.db file

        Args:
          self: The
          master: no master, this is the first instance of a window

        Raises:
          Any errors raised should be put here

        """
        super().__init__(parent)
        self.geometry("500x80")
        error_msg = ttk.Label(
            self,
            text="Error: You must have the standards.db file downloaded within the same folder",
            style="ErrorMsg.TLabel"
        )

        okay = ttk.Button(
            self,
            text="Okay",
            command=lambda: parent.destroy(),
            style="Okay.TButton"
        )

        # define look of our widgets
        style = ttk.Style()
        style.configure(
            "ErrorMsg.TLabel",
            foreground="red",
            font=("Helvetica", 10)
        )
        style.configure(
            "Okay.TButton",
            background="white",
            font=("Helvetica", 10, "bold")
        )

        # place our widgets on the screen
        error_msg.grid(column=0, row=0)
        okay.grid(column=0, row=1)

        # catch whether a user exits early
        def if_closed():
            parent.destroy()

        self.protocol("WM_DELETE_WINDOW", if_closed)

        # make the window modal
        self.focus_set()
        self.grab_set()
        self.transient(parent)
        self.wait_window(self)
